0=${(%):-%N}
source ${0:A:h}/async.zsh
